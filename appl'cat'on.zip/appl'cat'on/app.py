import streamlit as st
import pandas as pd
import matplotlib.pyplot as plt
import io
from datetime import datetime

# ----------------- PAGE CONFIG -----------------
st.set_page_config(page_title="Smart Transport Selector", page_icon="🚦", layout="centered")

from streamlit.components.v1 import html







# ----------------- CUSTOM CSS -----------------
st.markdown("""
    <style>
        body {
            background-color: #f0f8ff;
            font-family: 'Segoe UI', sans-serif;
        }
        .title {
            text-align: center;
            font-size: 36px;
            color: #005f73;
            font-weight: bold;
            margin-top: 10px;
        }
        .subtitle {
            text-align: center;
            font-size: 18px;
            color: #222;
            margin-bottom: 20px;
        }
        .section {
            background-color: #ffffff;
            padding: 20px;
            border-radius: 12px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            margin-top: 25px;
        }
        .footer {
            text-align: center;
            font-size: small;
            color: gray;
            margin-top: 40px;
        }
        .icon-row img {
            height: 30px;
            margin-right: 10px;
        }
    </style>
""", unsafe_allow_html=True)

# ----------------- LOGO & HEADER -----------------
st.image("logo.png", width=200)
st.markdown("<div class='title'>Smart City Transportation System Selector</div>", unsafe_allow_html=True)
st.markdown("<div class='subtitle'>Using IF-CIMAS-ARLON Multi-Criteria Decision-Making</div>", unsafe_allow_html=True)

# ----------------- METHODOLOGY -----------------
st.markdown("### 📘 Methodology Explained")
with st.expander("View Methodology Summary"):
    st.markdown("""
    **IF-CIMAS-ARLON** combines fuzzy logic with expert judgment to rank alternatives:
    - **Intuitionistic Fuzzy Numbers (IFN)** handle uncertainty in linguistic ratings
    - **Reliability Index (RI)** checks how consistent an expert is
    - **IF-CIMAS** weights criteria based on RI-adjusted expert input
    - **IF-ARLON** ranks each transportation alternative using aggregated IFNs
    """)

# ----------------- FILE UPLOAD -----------------
st.markdown("### 📅 Upload Expert Evaluation Excel File")
uploaded_file = st.file_uploader("Upload .xlsx file", type=["xlsx"])

if uploaded_file:
    try:
        with st.container():
            df = pd.read_excel(uploaded_file)
            st.success("File uploaded successfully!")

            linguistic_to_ifn = {
                "Very Bad": (0.1, 0.9), "Bad": (0.3, 0.7), "Poor": (0.3, 0.7),
                "Fair": (0.5, 0.5), "Good": (0.7, 0.3), "Very Good": (0.9, 0.1)
            }

            criteria = [c for c in df.columns if c not in ['Expert', 'Alternative']]
            experts = df['Expert'].unique()
            alternatives = df['Alternative'].unique()

            def convert_to_ifn(row):
                return {c: linguistic_to_ifn.get(str(row[c]).strip(), (0.5, 0.5)) for c in criteria}

            df['IFNs'] = df.apply(convert_to_ifn, axis=1)

            def compute_ri(expert_df):
                score = 0
                for row in expert_df['IFNs']:
                    for m, n in row.values():
                        score += 1 - abs(1 - m - n)
                return score / (len(expert_df) * len(criteria))

            expert_ri = {e: compute_ri(df[df['Expert'] == e]) for e in experts}

            st.markdown("### 🔢 Expert Reliability Index (RI)", unsafe_allow_html=True)
            st.dataframe(pd.DataFrame(list(expert_ri.items()), columns=["Expert", "RI"]))

            aggregated_ifn = {alt: {c: (0, 0) for c in criteria} for alt in alternatives}
            for alt in alternatives:
                for c in criteria:
                    total_m = total_n = total_w = 0
                    for expert in experts:
                        row = df[(df['Alternative'] == alt) & (df['Expert'] == expert)]
                        if not row.empty:
                            m, n = row.iloc[0]['IFNs'][c]
                            w = expert_ri[expert]
                            total_m += w * m
                            total_n += w * n
                            total_w += w
                    if total_w > 0:
                        aggregated_ifn[alt][c] = (total_m / total_w, total_n / total_w)

            st.markdown("### 🔄 Aggregated IFN Matrix")
            agg_display = pd.DataFrame({alt: {c: f"({m:.2f}, {n:.2f})" for c, (m, n) in aggregated_ifn[alt].items()} for alt in aggregated_ifn}).T
            st.dataframe(agg_display)

            def if_arlon_score(ifn_dict):
                return sum(m - n for m, n in ifn_dict.values()) / len(ifn_dict)

            result = [(alt, if_arlon_score(aggregated_ifn[alt])) for alt in alternatives]
            result.sort(key=lambda x: x[1], reverse=True)
            result_df = pd.DataFrame(result, columns=["Alternative", "Score"])

            st.markdown("### 🏆 Final Ranking")
            st.dataframe(result_df.style.highlight_max(axis=0, color='lightgreen'))

            st.markdown("### 📊 Ranking Visualization")
            fig, ax = plt.subplots()
            ax.bar(result_df["Alternative"], result_df["Score"], color="#0077b6")
            ax.set_ylabel("Score")
            ax.set_title("Smart Transportation Options")
            st.pyplot(fig)

            output = io.BytesIO()
            with pd.ExcelWriter(output, engine='openpyxl') as writer:
                result_df.to_excel(writer, index=False, sheet_name="Final Ranking")
                pd.DataFrame(list(expert_ri.items()), columns=["Expert", "RI"]).to_excel(writer, index=False, sheet_name="Expert RIs")
                agg_display.to_excel(writer, sheet_name="Aggregated IFNs")
            st.download_button("📥 Download All Results (Excel)", output.getvalue(), file_name="if_cimas_arlon_results.xlsx")

    except Exception as e:
        st.error(f"Error: {e}")
else:
    st.info("Please upload a valid Excel file to continue.")

# Footer
st.markdown("<div class='footer'>Smart City Transportation System Selection using IF-CIMAS-ARLON | Istinye University | © {}<br>Enhanced with smart transportation visuals and style</div>".format(datetime.now().year), unsafe_allow_html=True)
