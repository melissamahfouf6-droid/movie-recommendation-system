import pandas as pd

# --------------------------
# 1. Linguistic → IFN Mapping
# --------------------------
linguistic_to_ifn = {
    "Very Bad": (0.1, 0.9),
    "Bad": (0.3, 0.7),
    "Poor": (0.3, 0.7),
    "Fair": (0.5, 0.5),
    "Good": (0.7, 0.3),
    "Very Good": (0.9, 0.1)
}

# --------------------------
# 2. Load Excel Data
# --------------------------
file_path = "smart_transport_if_cimas.xlsx"
df = pd.read_excel(file_path)

criteria = [col for col in df.columns if col not in ['Expert', 'Alternative']]
experts = df['Expert'].unique()
alternatives = df['Alternative'].unique()

# --------------------------
# 3. Convert Linguistic to IFNs
# --------------------------
def convert_to_ifn(row):
    return {c: linguistic_to_ifn.get(str(row[c]).strip(), (0.5, 0.5)) for c in criteria}

df['IFNs'] = df.apply(convert_to_ifn, axis=1)

# --------------------------
# 4. Compute Reliability Index (RI) for Each Expert
# --------------------------
def compute_ri(expert_df):
    score = 0
    for row in expert_df['IFNs']:
        for m, n in row.values():
            hesitation = 1 - m - n
            score += 1 - abs(hesitation)  # less hesitation = higher RI
    return score / (len(expert_df) * len(criteria))

expert_ri = {
    expert: compute_ri(df[df['Expert'] == expert])
    for expert in experts
}

# --------------------------
# 5. Aggregate IFNs per Alternative
# --------------------------
from collections import defaultdict

aggregated_ifn = {alt: {c: (0, 0) for c in criteria} for alt in alternatives}

for alt in alternatives:
    for c in criteria:
        total_m = 0
        total_n = 0
        total_weight = 0
        for expert in experts:
            expert_rows = df[(df['Alternative'] == alt) & (df['Expert'] == expert)]
            if not expert_rows.empty:
                m, n = expert_rows.iloc[0]['IFNs'][c]
                w = expert_ri[expert]
                total_m += w * m
                total_n += w * n
                total_weight += w
        if total_weight > 0:
            aggregated_ifn[alt][c] = (total_m / total_weight, total_n / total_weight)

# --------------------------
# 6. Calculate IF-ARLON Score
# --------------------------
def if_arlon_score(ifn_dict):
    return sum((m - n) for m, n in ifn_dict.values()) / len(ifn_dict)

ranking_results = []
for alt in alternatives:
    score = if_arlon_score(aggregated_ifn[alt])
    ranking_results.append((alt, score))

ranking_results.sort(key=lambda x: x[1], reverse=True)

# --------------------------
# 7. Output Final Ranking
# --------------------------
print("\n🚦 Final IF-CIMAS-ARLON Ranking:\n")
for rank, (alt, score) in enumerate(ranking_results, start=1):
    print(f"{rank}. {alt} — Score: {score:.4f}")

# Optional: Save results to Excel
result_df = pd.DataFrame(ranking_results, columns=["Alternative", "Score"])
result_df.to_excel("final_ranking_output.xlsx", index=False)
print("\n📁 Results saved to 'final_ranking_output.xlsx'")
